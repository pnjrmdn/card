<link rel="stylesheet" href="assets/my.css">
<script src="https://kit.fontawesome.com/a225635cc4.js" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
<link rel="stylesheet" href="https://pattern.kivan-works.com/fonts/kredit.css">
<!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script> -->

<style>
  * {
    background-repeat: no-repeat;
  }

  html {
    height: 100%;
    width: 100%;
    /* overflow: hidden; */
  }

  body {
    height: 100%;
    display: flex;
    background: linear-gradient(125deg, #fbd7e5, #bdf4fa);
  }

  .card_body {
    padding: 0.75rem 1.75rem;
  }

  .active .floating:before {
    opacity: 1;
    transition: 500ms;
  }

  .floating:before {
    font-family: "Quicksand";
    font-weight: bold;
    /* content: "Keep Moving Your Mouse!"; */
    width: 100%;
    text-align: center;
    font-size: 2rem;
    position: absolute;
    top: -70px;
    opacity: 0;
    transition: 300ms;
    background: -webkit-linear-gradient(145deg, #4684c1, #343174);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .floating {
    font-family: Inconsolata;
    margin: auto;
    width: 453px;
    height: 280px;
    box-shadow: -20px 14px 54px rgba(0, 0, 0, 0.55);
    font-size: 18px;
    border-radius: 8px;
    transform-style: preserve-3d;
    transform-origin: 50% 50%;
    background: linear-gradient(145deg, #4684c1, #343174);
    transform: rotateX(17deg) rotateY(18deg);
  }

  .logo {
    height: 60px;
    transform: translateZ(30px);
    text-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
    margin: 0;
    font-weight: normal;
    filter: drop-shadow(-6.4px 6.2px 8px rgba(0, 0, 0, 0.6));
    z-index: 20;
    background-image: url("data:image/svg+xml;charset=utf8,%3C?xml version='1.0' encoding='UTF-8' standalone='no'?%3E%3C!-- Created with Inkscape (http://www.inkscape.org/) --%3E%3Csvg xmlns:svg='http://www.w3.org/2000/svg' xmlns='http://www.w3.org/2000/svg' version='1.0' width='110px' height='60px' viewBox='0 0 600 160' id='svg2268'%3E%3Cdefs id='defs2270' /%3E%3Cg transform='translate(-162.85714,-252.25207)' id='layer1'%3E%3Cg transform='matrix(2107.2671,0,0,2111.3537,195.14296,-1206.6414)' id='g2249'%3E%3Cpath d='M 148.625,506.09375 L 148.15625,506.125 L 147.6875,506.125 L 147.25,506.15625 L 146.34375,506.21875 L 145.46875,506.3125 L 144.625,506.4375 L 143.78125,506.5625 L 143,506.6875 L 142.21875,506.875 L 141.46875,507 L 140.71875,507.1875 L 140.03125,507.34375 L 139.34375,507.5 L 138.6875,507.65625 L 138.03125,507.8125 L 137.4375,507.96875 L 136.8125,508.0625 L 135.875,515.875 C 137.42498,515.13748 142.31253,513.78125 146.375,513.65625 C 150.42498,513.53127 152.82499,514.40002 152,517.875 C 139.95007,517.87497 131.81874,520.33755 130.15625,528.125 C 127.76877,541.49993 142.43129,541.13746 148.28125,535.3125 L 147.5625,538.53125 L 158.3125,538.53125 L 162.96875,517.25 C 164.88123,508.21253 156.64995,505.96875 149.125,506.09375 L 148.625,506.09375 z M 147.8125,525.03125 C 148.63749,525.03125 149.61251,525.03125 150.4375,525.03125 C 150.20001,526.01874 150.06875,526.88751 149.84375,527.875 L 149.78125,528.125 L 149.6875,528.40625 L 149.625,528.625 L 149.53125,528.875 L 149.4375,529.09375 L 149.3125,529.3125 L 149.21875,529.53125 L 149.09375,529.71875 L 148.96875,529.90625 L 148.8125,530.09375 L 148.6875,530.25 L 148.53125,530.4375 L 148.375,530.59375 L 148.1875,530.75 L 148,530.875 L 147.84375,531 L 147.65625,531.125 L 147.4375,531.25 L 147.25,531.34375 L 147.0625,531.4375 L 146.84375,531.5625 L 146.625,531.625 L 146.40625,531.71875 L 146.1875,531.78125 L 145.9375,531.84375 L 145.71875,531.90625 L 145.46875,531.9375 L 145.25,532 L 145,532.03125 L 144.75,532.0625 L 144.5,532.0625 L 144.21875,532.09375 C 141.83126,532.21878 139.68751,530.09998 141.25,527.625 C 142.4375,525.51252 145.77501,525.03125 147.8125,525.03125 z ' transform='scale(1.3888889e-3,1.3888889e-3)' style='font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;letter-spacing:normal;word-spacing:normal;text-anchor:start;fill:%23FFFFFF;fill-opacity:1;fill-rule:evenodd;stroke:%23FFFFFF;stroke-width:0;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:10.43299961;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1' id='path42' /%3E%3Cpolygon points='155.71,285.86 148.61,253.18 157.34,253.18 164.53,285.86 155.71,285.86 ' transform='matrix(1.7361e-3,0,0,-1.7361e-3,-3.125e-2,1.1875)' style='font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;letter-spacing:normal;word-spacing:normal;text-anchor:start;fill:%23FFFFFF;fill-opacity:1;fill-rule:evenodd;stroke:%23FFFFFF;stroke-width:0;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:10.43299961;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1' id='polygon44' /%3E%3Cpath d='M 102.0625,497.8125 L 93.21875,538.53125 L 104.8125,538.53125 L 107.8125,525.03125 L 116.0625,525.03125 C 124.19995,525.03125 130.88751,520.0812 132.6875,511.65625 C 134.72498,502.1313 127.76871,497.8125 122.03125,497.8125 L 102.0625,497.8125 z M 111.875,506.09375 L 117.625,506.09375 C 120.61248,506.09375 122.4,508.56877 121.6875,511.65625 L 121.59375,511.9375 L 121.5,512.25 L 121.40625,512.5 L 121.3125,512.78125 L 121.1875,513.0625 L 121.03125,513.3125 L 120.875,513.59375 L 120.71875,513.84375 L 120.5625,514.09375 L 120.375,514.3125 L 120.1875,514.5625 L 120,514.78125 L 119.78125,515 L 119.5625,515.21875 L 119.34375,515.40625 L 119.125,515.625 L 118.875,515.8125 L 118.625,515.96875 L 118.375,516.125 L 118.125,516.28125 L 117.875,516.4375 L 117.625,516.5625 L 117.34375,516.6875 L 117.09375,516.8125 L 116.8125,516.90625 L 116.53125,517 L 116.25,517.0625 L 115.96875,517.125 L 115.6875,517.1875 L 115.4375,517.21875 L 115.125,517.21875 L 114.875,517.25 L 109.46875,517.25 L 111.875,506.09375 z ' transform='scale(1.3888889e-3,1.3888889e-3)' style='font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;letter-spacing:normal;word-spacing:normal;text-anchor:start;fill:%23FFFFFF;fill-opacity:1;fill-rule:evenodd;stroke:%23FFFFFF;stroke-width:0;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:10.43299961;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1' id='path48' /%3E%3Cpath d='M 44.0625,506.09375 L 43.59375,506.125 L 43.15625,506.125 L 42.6875,506.15625 L 41.8125,506.21875 L 40.9375,506.3125 L 40.09375,506.4375 L 39.28125,506.5625 L 38.5,506.6875 L 37.75,506.875 L 37,507 L 36.28125,507.1875 L 35.59375,507.34375 L 34.9375,507.5 L 34.28125,507.65625 L 33.6875,507.8125 L 33.09375,507.96875 L 32.53125,508.0625 L 31.59375,515.875 C 33.004992,515.13748 37.840026,513.78125 41.84375,513.65625 C 45.852475,513.53127 48.208745,514.40002 47.5,517.875 C 35.596327,517.87497 27.588739,520.33755 25.9375,528.125 C 23.580015,541.49993 38.063786,541.13746 43.71875,535.3125 L 43,538.53125 L 53.75,538.53125 L 58.34375,517.25 C 60.233738,508.21253 51.952453,505.96875 44.53125,506.09375 L 44.0625,506.09375 z M 43.25,525.03125 C 44.192495,525.03125 45.026256,525.03125 45.96875,525.03125 C 45.733752,526.01874 45.497499,526.88751 45.375,527.875 L 45.3125,528.125 L 45.25,528.40625 L 45.15625,528.625 L 45.0625,528.875 L 44.96875,529.09375 L 44.84375,529.3125 L 44.75,529.53125 L 44.625,529.71875 L 44.46875,529.90625 L 44.34375,530.09375 L 44.1875,530.25 L 44.03125,530.4375 L 43.875,530.59375 L 43.6875,530.75 L 43.53125,530.875 L 43.34375,531 L 43.15625,531.125 L 42.9375,531.25 L 42.75,531.34375 L 42.53125,531.4375 L 42.3125,531.5625 L 42.09375,531.625 L 41.875,531.71875 L 41.65625,531.78125 L 41.4375,531.84375 L 41.1875,531.90625 L 40.9375,531.9375 L 40.71875,532 L 40.46875,532.03125 L 40.21875,532.0625 L 39.96875,532.0625 L 39.71875,532.09375 C 37.360016,532.21878 35.34126,530.09998 36.875,527.625 C 38.051242,525.51252 41.365012,525.03125 43.25,525.03125 z ' transform='scale(1.3888889e-3,1.3888889e-3)' style='font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;letter-spacing:normal;word-spacing:normal;text-anchor:start;fill:%23FFFFFF;fill-opacity:1;fill-rule:evenodd;stroke:%23FFFFFF;stroke-width:0;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:10.43299961;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1' id='path52' /%3E%3Cpolygon points='68.406,278.65 76.984,278.65 78.367,263.48 86.762,278.65 95.613,278.65 75.23,242.35 65.637,242.35 71.91,253.02 68.406,278.65 ' transform='matrix(1.7361e-3,0,0,-1.7361e-3,-3.125e-2,1.1875)' style='font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;letter-spacing:normal;word-spacing:normal;text-anchor:start;fill:%23FFFFFF;fill-opacity:1;fill-rule:evenodd;stroke:%23FFFFFF;stroke-width:0;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:10.43299961;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1' id='polygon54' /%3E%3Cpath d='M -2.15625,497.8125 L -11.03125,538.53125 L 0.71875,538.53125 L 3.59375,525.03125 L 12,525.03125 C 20.031199,525.03125 26.735011,520.0812 28.53125,511.65625 C 30.567487,502.1313 23.748712,497.8125 17.875,497.8125 L -2.15625,497.8125 z M 7.8125,506.09375 L 13.5625,506.09375 C 16.438731,506.09375 18.339995,508.56877 17.5,511.65625 L 17.4375,511.9375 L 17.34375,512.25 L 17.25,512.5 L 17.125,512.78125 L 17,513.0625 L 16.875,513.3125 L 16.75,513.59375 L 16.59375,513.84375 L 16.40625,514.09375 L 16.25,514.3125 L 16.0625,514.5625 L 15.875,514.78125 L 15.65625,515 L 15.4375,515.21875 L 15.21875,515.40625 L 15,515.625 L 14.78125,515.8125 L 14.53125,515.96875 L 14.3125,516.125 L 14.0625,516.28125 L 13.78125,516.4375 L 13.53125,516.5625 L 13.28125,516.6875 L 13,516.8125 L 12.75,516.90625 L 12.46875,517 L 12.1875,517.0625 L 11.90625,517.125 L 11.625,517.1875 L 11.34375,517.21875 L 11.0625,517.21875 L 10.78125,517.25 L 5.28125,517.25 L 7.8125,506.09375 z ' transform='scale(1.3888889e-3,1.3888889e-3)' style='font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;letter-spacing:normal;word-spacing:normal;text-anchor:start;fill:%23FFFFFF;fill-opacity:1;fill-rule:evenodd;stroke:%23FFFFFF;stroke-width:0;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:10.43299961;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1' id='path58' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
  }

  .chips {
    margin-top: 17px;
    margin-left: -1px;
    height: 70px;
    width: 80px;
    filter: drop-shadow(-6.4px 6.2px 8px rgba(0, 0, 0, 0.6));
    transform: translateZ(25px);
    background-repeat: no-repeat;
    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='50px' x='0px' y='0px' viewBox='0 0 40 40' style='enable-background:new 0 0 40 40;' xml:space='preserve'%3E%3Cg id='surface1'%3E%3Cpath fill='%23F5CE85' d='M8.9,34.5c-6.4,0.1-6.4,0.1-6.4-6.4V11.9c0-3.5-0.1-6.4,3.4-6.4h25.3c6.4,0,6.4,0,6.4,6.4v16.3 c0,6.4,0,6.4-6.4,6.4L8.9,34.5z'/%3E%3Cpath fill='%23967A44' d='M31.1,6C37,6,37,6,37,11.9v16.3c0,5.9,0,5.9-5.9,5.9H8.9c-5.9,0-5.9,0-5.9-6V11.9C3,8.2,2.7,6,6,6H31.1 M31.1,5H9.2C2.3,5,2,5,2,11.9v16.3C2,35,2,35,8.9,35h22.3c6.9-0.1,6.9-0.1,6.9-6.9V11.9C38.1,5,38.1,5,31.1,5z'/%3E%3Cpath fill='%23967A44' d='M29,35c-3.3,0-6-2.7-6-6s2.7-6,6-6h8.5v1H29c-2.8,0-5,2.2-5,5s2.2,5,5,5V35z'/%3E%3Cpath fill='%23967A44' d='M11,35v-1c2.8,0,5-2.2,5-5s-2.2-5-5-5H2.5v-1H11c3.3,0,6,2.7,6,6S14.3,35,11,35z'/%3E%3Cpath fill='%23967A44' d='M37.5,17H27c-2.2,0-4-1.8-4-4s1.8-4,4-4h2.1v1H27c-1.7,0-3,1.3-3,3s1.3,3,3,3h10.5V17z'/%3E%3Cpath fill='%23967A44' d='M28,16h1v7.5h-1V16z'/%3E%3Cpath fill='%23967A44' d='M13,17H2.5v-1H13c1.7,0,3-1.3,3-3s-1.3-3-3-3h-2.1V9H13c2.2,0,4,1.8,4,4S15.2,17,13,17z'/%3E%3Cpath fill='%23967A44' d='M11,16h1v7.5h-1V16z'/%3E%3C/g%3E%3C/svg%3E");
  }

  .paywave {
    transform: translateZ(30px);
    float: right;
    position: absolute;
    margin: 15px 5px;
    top: 0;
    right: 0;
    filter: drop-shadow(0px 0px 5px rgba(0, 0, 0, 0.5));
    filter: drop-shadow(-6.4px 6.2px 8px rgba(0, 0, 0, 0.6));
    height: 50px;
    width: 50px;
    background-repeat: no-repeat;
    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='30' height='56' viewBox='0 0 46 56'%3E%3Ctitle%3EContactlessIndicator 000%3C/title%3E%3Cpath fill='none' stroke='%23FFF' stroke-width='6' stroke-linecap='round' d='m35,3a50,50 0 0,1 0,50M24,8.5a39,39 0 0,1 0,39M13.5,13.55a28.2,28.5 0 0,1 0,28.5M3,19a18,17 0 0,1 0,18'/%3E%3C/svg%3E");
  }

  .paypal_center {
    height: 300px;
    width: 300px;
    position: absolute;
    top: 20px;
    left: 50%;
    transform: translateZ(5px);
    margin-left: -75px;
    z-index: 1;
    filter: drop-shadow(-6.4px 6.2px 8px rgba(0, 0, 0, 0.6));
    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg width='150px' height='252px' viewBox='0 0 256 302' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' preserveAspectRatio='xMidYMid'%3E%3Cg%3E%3Cpath d='M217.168476,23.5070146 C203.234077,7.62479651 178.045612,0.815753338 145.823355,0.815753338 L52.3030619,0.815753338 C45.7104431,0.815753338 40.1083819,5.6103852 39.0762042,12.1114399 L0.136468302,259.076601 C-0.637664968,263.946149 3.13311322,268.357876 8.06925331,268.357876 L65.804612,268.357876 L80.3050438,176.385849 L79.8555471,179.265958 C80.8877248,172.764903 86.4481659,167.970272 93.0324607,167.970272 L120.46841,167.970272 C174.366398,167.970272 216.569147,146.078116 228.897012,82.7490197 C229.263268,80.8761167 229.579581,79.0531577 229.854273,77.2718188 C228.297683,76.4477414 228.297683,76.4477414 229.854273,77.2718188 C233.525163,53.8646924 229.829301,37.9325302 217.168476,23.5070146' fill='%2327346A'%3E%3C/path%3E%3Cpath d='M102.396976,68.8395929 C103.936919,68.1070797 105.651665,67.699203 107.449652,67.699203 L180.767565,67.699203 C189.449511,67.699203 197.548776,68.265236 204.948824,69.4555699 C207.071448,69.7968545 209.127479,70.1880831 211.125242,70.6375799 C213.123006,71.0787526 215.062501,71.5781934 216.943728,72.1275783 C217.884341,72.4022708 218.808307,72.6852872 219.715624,72.9849517 C223.353218,74.2002577 226.741092,75.61534 229.854273,77.2718188 C233.525163,53.8563683 229.829301,37.9325302 217.168476,23.5070146 C203.225753,7.62479651 178.045612,0.815753338 145.823355,0.815753338 L52.2947379,0.815753338 C45.7104431,0.815753338 40.1083819,5.6103852 39.0762042,12.1114399 L0.136468302,259.068277 C-0.637664968,263.946149 3.13311322,268.349552 8.0609293,268.349552 L65.804612,268.349552 L95.8875974,77.5798073 C96.5035744,73.6675208 99.0174265,70.4627756 102.396976,68.8395929 Z' fill='%2327346A'%3E%3C/path%3E%3Cpath d='M228.897012,82.7490197 C216.569147,146.069792 174.366398,167.970272 120.46841,167.970272 L93.0241367,167.970272 C86.4398419,167.970272 80.8794007,172.764903 79.8555471,179.265958 L61.8174095,293.621258 C61.1431644,297.883153 64.4394738,301.745495 68.7513129,301.745495 L117.421821,301.745495 C123.182038,301.745495 128.084882,297.550192 128.983876,291.864891 L129.458344,289.384335 L138.631407,231.249423 L139.222412,228.036354 C140.121406,222.351053 145.02425,218.15575 150.784467,218.15575 L158.067979,218.15575 C205.215193,218.15575 242.132193,199.002194 252.920115,143.605884 C257.423406,120.456802 255.092683,101.128442 243.181019,87.5519756 C239.568397,83.4399129 235.081754,80.0437153 229.854273,77.2718188 C229.571257,79.0614817 229.263268,80.8761167 228.897012,82.7490197 L228.897012,82.7490197 Z' fill='%232790C3'%3E%3C/path%3E%3Cpath d='M216.952052,72.1275783 C215.070825,71.5781934 213.13133,71.0787526 211.133566,70.6375799 C209.135803,70.1964071 207.071448,69.8051785 204.957148,69.4638939 C197.548776,68.265236 189.457835,67.699203 180.767565,67.699203 L107.457976,67.699203 C105.651665,67.699203 103.936919,68.1070797 102.4053,68.8479169 C99.0174265,70.4710996 96.5118984,73.6675208 95.8959214,77.5881313 L80.3133678,176.385849 L79.8638711,179.265958 C80.8877248,172.764903 86.4481659,167.970272 93.0324607,167.970272 L120.476734,167.970272 C174.374722,167.970272 216.577471,146.078116 228.905336,82.7490197 C229.271592,80.8761167 229.579581,79.0614817 229.862597,77.2718188 C226.741092,75.623664 223.361542,74.2002577 219.723948,72.9932757 C218.816631,72.6936112 217.892665,72.4022708 216.952052,72.1275783' fill='%231F264F'%3E%3C/path%3E%3C/g%3E%3C/svg%3E");
  }

  .card_no {
    transform: translateZ(40px);
    font-family: kredit-front;
    font-weight: bold;
    font-size: 1.8rem;
    color: #fff;
    position: absolute;
    letter-spacing: 3px;
    bottom: 90px;
    z-index: 2;
    text-shadow: 0 0 5px rgba(0, 0, 0, 0.8);
    text-shadow: -9px 8.7px 6px rgba(0, 0, 0, 0.8);
    width: calc(100% - 3.5rem);
    text-align: center;
  }

  .valid {
    position: absolute;
    bottom: 56px;
    color: #fff;
    font-size: 0.58rem;
    left: 146px;
    text-shadow: 0 0 5px rgba(0, 0, 0, 0.8);
    text-shadow: -9px 8.7px 6px rgba(0, 0, 0, 0.8);
    transform: translateZ(30px);
  }

  .valid_date {
    position: absolute;
    font-family: kredit-front;
    font-size: 1.5rem;
    font-weight: bold;
    color: #fff;
    text-shadow: 0 0 5px rgba(0, 0, 0, 0.8);
    text-shadow: -9px 8.7px 6px rgba(0, 0, 0, 0.8);
    bottom: 54px;
    left: 180px;
    z-index: 20;
    transform: translateZ(30px);
    letter-spacing: 2px;
  }

  .holder {
    position: absolute;
    font-family: kredit-front;
    font-size: 1.5rem;
    font-weight: bold;
    color: #fff;
    text-shadow: 0 0 5px rgba(0, 0, 0, 0.8);
    text-shadow: -9px 8.7px 6px rgba(0, 0, 0, 0.8);
    bottom: 20px;
    left: 30px;
    z-index: 20;
    letter-spacing: 2px;
    transform: translateZ(50px);
  }

  .mastercard_icon {
    height: 85px;
    width: 95px;
    float: right;
    position: absolute;
    right: 0;
    bottom: 0;
    transform: translateZ(30px);
    filter: drop-shadow(0px 0px 5px rgba(0, 0, 0, 0.3));
    filter: drop-shadow(-6.4px 6.2px 8px rgba(0, 0, 0, 0.6));
    background-repeat: no-repeat;
    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg width='75' height='75' viewBox='0 0 200 155' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:cc='http://creativecommons.org/ns%23' xmlns:dc='http://purl.org/dc/elements/1.1/' xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns%23'%3E%3Cmetadata%3E%3Crdf:RDF%3E%3Ccc:Work rdf:about=''%3E%3Cdc:format%3Eimage/svg+xml%3C/dc:format%3E%3Cdc:type rdf:resource='http://purl.org/dc/dcmitype/StillImage'/%3E%3Cdc:title/%3E%3C/cc:Work%3E%3C/rdf:RDF%3E%3C/metadata%3E%3Cg transform='translate(1565.7 -1106.8)'%3E%3Cg transform='matrix(3.1437 0 0 3.1437 -4835.7 -1027.6)'%3E%3Cg transform='matrix(1.25 0 0 -1.25 1102.5 727.74)'%3E%3Cpath d='m0 0v-0.103h0.095c0.021 0 0.039 5e-3 0.052 0.013 0.012 8e-3 0.019 0.022 0.019 0.039s-7e-3 0.03-0.019 0.038c-0.013 9e-3 -0.031 0.013-0.052 0.013zm0.096 0.072c0.049 0 0.087-0.011 0.114-0.033s0.04-0.052 0.04-0.09c0-0.032-0.01-0.058-0.032-0.079-0.021-0.02-0.051-0.033-0.091-0.038l0.126-0.145h-0.098l-0.117 0.144h-0.038v-0.144h-0.082v0.385zm-0.025-0.518c0.045 0 0.087 9e-3 0.125 0.026 0.039 0.017 0.073 0.04 0.102 0.069s0.052 0.063 0.069 0.103c0.016 0.039 0.025 0.081 0.025 0.126s-9e-3 0.087-0.025 0.126c-0.017 0.039-0.04 0.074-0.069 0.103s-0.063 0.052-0.102 0.069c-0.038 0.016-0.08 0.024-0.125 0.024s-0.088-8e-3 -0.127-0.024c-0.04-0.017-0.075-0.04-0.104-0.069s-0.052-0.064-0.068-0.103c-0.017-0.039-0.025-0.081-0.025-0.126s8e-3 -0.087 0.025-0.126c0.016-0.04 0.039-0.074 0.068-0.103s0.064-0.052 0.104-0.069c0.039-0.017 0.082-0.026 0.127-0.026m0 0.739c0.059 0 0.113-0.011 0.165-0.033 0.051-0.021 0.095-0.051 0.134-0.089 0.038-0.037 0.068-0.081 0.09-0.132 0.022-0.05 0.033-0.104 0.033-0.161s-0.011-0.111-0.033-0.161-0.052-0.094-0.09-0.132c-0.039-0.037-0.083-0.067-0.134-0.089-0.052-0.022-0.106-0.033-0.165-0.033-0.06 0-0.115 0.011-0.167 0.033s-0.097 0.052-0.135 0.089c-0.038 0.038-0.068 0.082-0.09 0.132s-0.033 0.104-0.033 0.161 0.011 0.111 0.033 0.161c0.022 0.051 0.052 0.095 0.09 0.132 0.038 0.038 0.083 0.068 0.135 0.089 0.052 0.022 0.107 0.033 0.167 0.033m-38.961 1.483c0 0.734 0.481 1.337 1.267 1.337 0.751 0 1.258-0.577 1.258-1.337s-0.507-1.337-1.258-1.337c-0.786 0-1.267 0.603-1.267 1.337m3.381 0v2.088h-0.908v-0.507c-0.288 0.376-0.725 0.612-1.319 0.612-1.171 0-2.089-0.918-2.089-2.193 0-1.276 0.918-2.193 2.089-2.193 0.594 0 1.031 0.236 1.319 0.612v-0.507h0.908zm30.684 0c0 0.734 0.481 1.337 1.267 1.337 0.752 0 1.258-0.577 1.258-1.337s-0.506-1.337-1.258-1.337c-0.786 0-1.267 0.603-1.267 1.337m3.382 0v3.765h-0.909v-2.184c-0.288 0.376-0.725 0.612-1.319 0.612-1.171 0-2.089-0.918-2.089-2.193 0-1.276 0.918-2.193 2.089-2.193 0.594 0 1.031 0.236 1.319 0.612v-0.507h0.909zm-22.795 1.38c0.585 0 0.961-0.367 1.057-1.013h-2.167c0.097 0.603 0.463 1.013 1.11 1.013m0.018 0.813c-1.224 0-2.08-0.891-2.08-2.193 0-1.328 0.891-2.193 2.141-2.193 0.629 0 1.205 0.157 1.712 0.585l-0.445 0.673c-0.35-0.279-0.796-0.437-1.215-0.437-0.585 0-1.118 0.271-1.249 1.023h3.101c9e-3 0.113 0.018 0.227 0.018 0.349-9e-3 1.302-0.813 2.193-1.983 2.193m10.964-2.193c0 0.734 0.481 1.337 1.267 1.337 0.751 0 1.258-0.577 1.258-1.337s-0.507-1.337-1.258-1.337c-0.786 0-1.267 0.603-1.267 1.337m3.381 0v2.088h-0.908v-0.507c-0.289 0.376-0.725 0.612-1.319 0.612-1.171 0-2.089-0.918-2.089-2.193 0-1.276 0.918-2.193 2.089-2.193 0.594 0 1.03 0.236 1.319 0.612v-0.507h0.908zm-8.509 0c0-1.267 0.882-2.193 2.228-2.193 0.629 0 1.048 0.14 1.502 0.498l-0.436 0.734c-0.341-0.245-0.699-0.376-1.093-0.376-0.725 9e-3 -1.258 0.533-1.258 1.337s0.533 1.328 1.258 1.337c0.394 0 0.752-0.131 1.093-0.376l0.436 0.734c-0.454 0.358-0.873 0.498-1.502 0.498-1.346 0-2.228-0.926-2.228-2.193m11.707 2.193c-0.524 0-0.865-0.245-1.101-0.612v0.507h-0.9v-4.176h0.909v2.341c0 0.691 0.297 1.075 0.891 1.075 0.184 0 0.376-0.026 0.568-0.105l0.28 0.856c-0.201 0.079-0.463 0.114-0.647 0.114m-24.341-0.437c-0.437 0.288-1.039 0.437-1.703 0.437-1.058 0-1.739-0.507-1.739-1.337 0-0.681 0.507-1.101 1.441-1.232l0.429-0.061c0.498-0.07 0.733-0.201 0.733-0.437 0-0.323-0.332-0.507-0.952-0.507-0.629 0-1.083 0.201-1.389 0.437l-0.428-0.707c0.498-0.367 1.127-0.542 1.808-0.542 1.206 0 1.905 0.568 1.905 1.363 0 0.734-0.55 1.118-1.459 1.249l-0.428 0.062c-0.393 0.052-0.708 0.13-0.708 0.41 0 0.306 0.297 0.489 0.795 0.489 0.533 0 1.049-0.201 1.302-0.358zm11.716 0.437c-0.524 0-0.865-0.245-1.1-0.612v0.507h-0.9v-4.176h0.908v2.341c0 0.691 0.297 1.075 0.891 1.075 0.184 0 0.376-0.026 0.568-0.105l0.28 0.856c-0.201 0.079-0.463 0.114-0.647 0.114m-7.749-0.105h-1.485v1.267h-0.918v-1.267h-0.847v-0.83h0.847v-1.905c0-0.969 0.376-1.546 1.45-1.546 0.394 0 0.848 0.122 1.136 0.323l-0.262 0.778c-0.271-0.157-0.568-0.236-0.804-0.236-0.454 0-0.602 0.28-0.602 0.699v1.887h1.485zm-13.577-4.176v2.621c0 0.987-0.629 1.651-1.643 1.66-0.533 9e-3 -1.083-0.157-1.468-0.743-0.288 0.463-0.742 0.743-1.38 0.743-0.446 0-0.882-0.131-1.223-0.62v0.515h-0.909v-4.176h0.917v2.315c0 0.725 0.402 1.11 1.023 1.11 0.603 0 0.908-0.393 0.908-1.101v-2.324h0.918v2.315c0 0.725 0.419 1.11 1.022 1.11 0.62 0 0.917-0.393 0.917-1.101v-2.324z' fill='%23FFFFFF'/%3E%3C/g%3E%3Cg transform='matrix(1.25 0 0 -1.25 1103.2 710.77)'%3E%3Cpath d='m0 0v0.61h-0.159l-0.184-0.419-0.183 0.419h-0.16v-0.61h0.113v0.46l0.172-0.397h0.117l0.172 0.398v-0.461zm-1.009 0v0.506h0.204v0.103h-0.52v-0.103h0.204v-0.506z' fill='%23f79410'/%3E%3C/g%3E%3Cpath d='m1080.6 714.05h-17.202v-30.915h17.202z' fill='%23ff5f00'/%3E%3Cg transform='matrix(1.25 0 0 -1.25 1064.5 698.59)'%3E%3Cpath d='m0 0c0 5.017 2.349 9.486 6.007 12.366-2.675 2.106-6.051 3.363-9.72 3.363-8.686 0-15.727-7.042-15.727-15.729s7.041-15.729 15.727-15.729c3.669 0 7.045 1.257 9.72 3.363-3.658 2.88-6.007 7.349-6.007 12.366' fill='%23eb001b'/%3E%3C/g%3E%3Cg transform='matrix(1.25 0 0 -1.25 1103.8 698.59)'%3E%3Cpath d='m0 0c0-8.687-7.041-15.729-15.727-15.729-3.669 0-7.045 1.257-9.721 3.363 3.659 2.88 6.008 7.349 6.008 12.366s-2.349 9.486-6.008 12.366c2.676 2.106 6.052 3.363 9.721 3.363 8.686 0 15.727-7.042 15.727-15.729' fill='%23f79e1b'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
  }

  .thickness {
    width: 453px;
    height: 280px;
    border-radius: 8px;
    position: absolute;
    background: linear-gradient(145deg, #4684c1, #343174);
    transform: translateZ(-4px);
  }

  .thickness:nth-child(2) {
    transform: translateZ(-8px);
  }

  .thickness:nth-child(3) {
    transform: translateZ(-11px);
  }
</style>

<body style="padding: 0px 90px 0px 90px !important">
  <!-- <div class="row"> -->
  <!-- <div class="col-sm-2 col-lg-3">

    </div> -->
  <div class="col col-sm col-atas">
    <!-- card -->

    <div class="floating">
      <div class="thickness"></div>
      <div class="thickness"></div>
      <div class="thickness"></div> 
      <div class="card_body">
        <!-- <div class="paypal_center svg"></div> -->
        <!-- <div class="logo svg"></div> -->
        <div class="paywave svg"></div>
        <div class="chips svg"></div>
        <div class="card_no text">
          Balance Rp. 500.000 <br>
          Cost Rp. -130.000 <br>
        </div>
        <div class="valid text">
          Month <br> Year
        </div>
        <div class="valid_date text">
          03/23
        </div>
        <div class="holder text">PANJI RAMADANU</div>
        <div class="mastercard_icon svg"></div>
      </div>
    </div> <br>
    <!-- </div> -->
    <!-- card -->



    <H6 style="color: black !important">Latest Transaction</H6>


    <!-- <div class="overflow-auto"> -->

    <div class="ex1">
      <?php
      for ($x = 0; $x <= 15; $x++) {
      ?>

        <div class="content-isi">
          <div class="row">
            <div class="col">
              Gorengan
              <p class="date-bawah">
                Monday, 2023-03-01
              </p>
            </div>
            <div class="col text-end">
              Rp. 6.000
            </div>
          </div>
        </div>

      <?php
      }
      ?>

      <!-- </div> -->
    </div> <br>


    <form> <br>

      <div class="row">
        <div class="col">
          <div class="mb-3 text-center">
            <label class="text-center"><b>Input Item Transaction</b></label>
            <input value="Gorengan" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            <!-- <div id="emailHelp" class="form-text">ex: Gorengan</div> -->
          </div>
        </div>
        <div class="col">
          <div class="mb-3 text-center">
            <label for="exampleInputEmail1" class="form-label text-center"><b>Price Rp.</b></label>
            <input value="6000" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            <!-- <div id="emailHelp" class="form-text">ex: Rp 1.000</div> -->
          </div>
        </div>
      </div>
      <div class="text-end">
      <button type="submit" class="btn btn-primary">Submit</button>
      </div>

    </form>

    <!-- batas col -->
  </div>

  <!-- <div class="col-sm-2 col-lg-3">

  </div> -->

</body>